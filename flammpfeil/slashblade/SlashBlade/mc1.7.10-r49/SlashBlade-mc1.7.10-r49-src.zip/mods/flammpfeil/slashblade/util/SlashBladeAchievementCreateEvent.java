package mods.flammpfeil.slashblade.util;

import cpw.mods.fml.common.eventhandler.Event;
import mods.flammpfeil.slashblade.stats.AchievementList;

/**
 * Created by Furia on 15/01/28.
 */
public class SlashBladeAchievementCreateEvent extends Event {
    public SlashBladeAchievementCreateEvent(){
    }
}
